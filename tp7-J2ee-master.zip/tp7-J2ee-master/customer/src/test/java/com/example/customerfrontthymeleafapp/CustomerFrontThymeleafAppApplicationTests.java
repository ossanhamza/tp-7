package com.example.customerfrontthymeleafapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerFrontThymeleafAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
